﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11.If_Statements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //the test that can be either True or False
            bool isMale = true;
            if (isMale) 
            {
                Console.WriteLine("You are male");
            }
            else 
            {
             Console.WriteLine("You are female");
            }
            //can also test 2 conditions ie AND is && in C#, OR is ||
            bool isTall = false;
            if (isTall && isMale)
            { 
             Console.WriteLine("You are both male and tall.");
            }
            else if (!isTall && isMale) //! means is not
            { 
             Console.WriteLine("You are not tall but you are male.");
            }
            else
            {
                Console.WriteLine("You are either not tall or not male.");
            }
            Console.ReadLine();
        }
    }
}
