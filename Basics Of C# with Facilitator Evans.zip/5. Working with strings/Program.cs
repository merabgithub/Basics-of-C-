﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.Working_with_strings
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This will write same line");
            Console.WriteLine("This will \n wrap to next line");
            Console.WriteLine("This will \" print out the quotation mark.");

            string firstName = "Mercy";
            string lastName = "Harris";
            //concatination
            Console.WriteLine(lastName +' '+ firstName);
           
            //Functions with strings
            Console.WriteLine(firstName +" "+"is"+" "+firstName.Length+" "+"letters");
            Console.WriteLine(lastName.Length);

            //methods of strings
            Console.WriteLine(firstName.ToUpper()); //change to uppercase
            Console.WriteLine(lastName.ToUpper());//change to lower case
            
            //method with parameter e.g the contains(), its case sensitive
            Console.WriteLine(lastName.Contains("Ha"));

            //acess characters using index
            Console.WriteLine(firstName[0]); //please note the index start counting from zero so M will be number 1

            //indexof will tell you iff the valuebis there and at what position
            Console.WriteLine("index of a is:");
            Console.WriteLine(lastName.IndexOf('a')); // can use double quotes too

            //substring, to grab from an index onwards
            Console.WriteLine(firstName.Substring(1));

            //you can also give index and length ie how many chars you wanna grab
            Console.WriteLine(firstName.Substring(1,2)) ;

            //freese console
            Console.Read();
        }
    }
}
