﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.Data_Types
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //declaration
            string name = "Mercy";
                int age = 10;

                bool isTall = false;
            double weight = 80.2; //large 
            
           // decimal
            //float //half of double
           
                Console.WriteLine(name + " " + "is" + " " + age + " " + "she weighs" + " " +  weight+"kg");
            Console.WriteLine("It is" + " " + isTall + " " + "that she is tall.");
            //freese console
            Console.Read();
        }
    }
}
