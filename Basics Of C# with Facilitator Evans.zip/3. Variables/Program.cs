﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.Variables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // declare variables
            string firstname;
            int age;

            //initialisation
            firstname = "mercy";
            age = 10;

            //what will be on the console
            //Console.WriteLine("firstname:");
            
            // + is used to concantinate the words. And the " " is meant to give a space.
            Console.WriteLine("Hi!"+ " " +firstname +" "+ "you are"+ " "+ age +" "+"years old");
            //Console.WriteLine("age:");
            // Console.WriteLine(age);
             
            //introduce a variable
            firstname = "Norma";
            age = 90;
            Console.WriteLine("Hi!" + " " + firstname + " " + "you are" + " " + age + " " + "years old");

            //introduce a variable
            string lastname = "Thomas";
            Console.WriteLine("Hi!" + " " + firstname + " " + lastname + " " + "you are" + " " + age);
            //freese console
            Console.ReadLine();
        }
    }
}
