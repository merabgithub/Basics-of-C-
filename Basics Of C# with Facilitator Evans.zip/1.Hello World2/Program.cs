﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.Hello_World2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World I am learning C#!");
            Console.WriteLine("I love this");
            
            Console.ReadLine();
        }
    }
}
