﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9.Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // OneWayAttribute is a way of creating an array
            int[] luckNumbers = { 4, 5, 8, 9 };
            Console.WriteLine(luckNumbers[0]);

            // if you wanna populate it later, the 5 is the size
            string[] friends = new string[5];
            friends[0] = "Mercy";
            friends[0] = "Marvin";
            friends[0] = "Harris";
            Console.WriteLine(friends[0]);
        }
    }
}
