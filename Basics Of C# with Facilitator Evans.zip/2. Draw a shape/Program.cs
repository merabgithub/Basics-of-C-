﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Draw_a_shape
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //This will draw a triangle.

            Console.WriteLine("      /|");
            Console.WriteLine("     / |");
            Console.WriteLine("    /  |");
            Console.WriteLine("   /   |");
            Console.WriteLine("  /    |");
            Console.WriteLine(" /     |");
            Console.WriteLine(" -------");
            
            //freeze frame
            Console.ReadLine();
        }
    }
}
