﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15.Switch_Statements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number (1-3): ");
            int number = int.Parse(Console.ReadLine()); // same as Convert.ToInt32

            switch (number)
            {
                case 1:
                    Console.Write("You entered '1'");
                    break;
                case 2:
                    Console.Write("You entered  '2'");
                    break;
                case 3:
                    Console.Write("You entered '3'");
                    break;
                default:
                    Console.Write("Invalid input. Please enter a number between 1 and 3.");
                    break;
            }
             Console.ReadLine();
        }


    }   
}
